# wg-repo-template

Use this repository as the starting point for any Working Group (WG).
Structure:
- /proposals
- /workflow
- /tasks/open, /tasks/in-progress, /tasks/completed
- /meeting-notes
- /reports
- /pull request (local copy of standard templates)

Follow the templates in `/templates` when creating docs.
