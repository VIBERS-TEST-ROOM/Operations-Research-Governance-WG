# Meeting Notes Template 

**Title:**
Enter WG/Meeting Title
 
**Author:**
Note Taker’s Name
 
**Date:**
DD/MM/YYYY 

**Meeting Number:**
update number 

**Attendees:**
List all participants.

**Agenda:**
List agenda items discussed in the meeting.
 
**Discussion Notes:**
Summarize discussions, decisions, and key points for each agenda item.

**Decisions Made:**
- Decision 1
- Decision 2

**Action Items:**
- [Task] – [Responsible Person] – [Deadline] 
- [Task] – [Responsible Person] – [Deadline] 

**Next Meeting (if applicable):**
Date & tentative agenda.

