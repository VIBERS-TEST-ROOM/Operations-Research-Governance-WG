# Task/Bounty Template

**Task Title:**
WG name and title

**Description:**
Clear description of the deliverable.

**Bounty**: 
$____ (stable equivalent)

**Timeline:**
- Start date:
- Due date:

**Assignment**:
- Assigned to: (Name / Handle / Wallet)
- Open Bounty: [Yes/No]

  **Status**:
- [ ] Open  
- [ ] In Progress  
- [ ] Completed  
  
**Submission Instructions:**
How should the work be submitted? (e.g., GitHub PR, file upload, link)

**Review Process:**
Reviewer(s): (WG Lead / designated reviewer/Poll)

**Completion Criteria:**
- [ ] Criteria 1
- [ ] Criteria 2
- [ ] Criteria 3

**Notes**:
[Optional: context, dependencies, or links]

